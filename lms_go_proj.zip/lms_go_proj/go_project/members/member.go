package members

import (
	"database/sql"
	"log"
	"net/http"
	"text/template"

	_ "github.com/go-sql-driver/mysql"
)

//Member is the representation of the member
type Member struct {
	Id      int
	Name    string
	Surname string
	Address string
	Phone   string
}

func dbConn() (db *sql.DB) {

	db, err := sql.Open("mysql", "root:turkey_12345@tcp/lms")
	if err != nil {
		panic(err.Error())
	}
	return db
}

var tmpl = template.Must(template.ParseGlob("form/*"))

//Index is the representation of the index tmpl
func Index(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	selDB, err := db.Query("SELECT * FROM member ORDER BY id ASC")
	if err != nil {
		panic(err.Error())
	}
	emp := Member{}
	res := []Member{}
	for selDB.Next() {
		var id int
		var name, surname, address, phone string
		err = selDB.Scan(&id, &name, &surname, &address, &phone)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Name = name
		emp.Surname = surname
		emp.Address = address
		emp.Phone = phone
		res = append(res, emp)
	}
	tmpl.ExecuteTemplate(w, "Index", res)
	defer db.Close()
}

//Show is the representation of the show tmpl
func Show(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM Member WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Member{}
	for selDB.Next() {
		var id int
		var name, surname, address, phone string
		err = selDB.Scan(&id, &name, &surname, &address, &phone)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Name = name
		emp.Surname = surname
		emp.Address = address
		emp.Phone = phone
	}
	tmpl.ExecuteTemplate(w, "Show", emp)
	defer db.Close()
}

//New is the representation of the new tmpl
func New(w http.ResponseWriter, r *http.Request) {
	tmpl.ExecuteTemplate(w, "New", nil)
}

//Edit is the representation of the edit tmpl
func Edit(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM Member WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Member{}
	for selDB.Next() {
		var id int
		var name, surname, address, phone string
		err = selDB.Scan(&id, &name, &surname, &address, &phone)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Name = name
		emp.Surname = surname
		emp.Address = address
		emp.Phone = phone
	}
	tmpl.ExecuteTemplate(w, "Edit", emp)
	defer db.Close()
}

//Insert is the representation of the insert tmpl
func Insert(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		name := r.FormValue("name")
		surname := r.FormValue("surname")
		address := r.FormValue("address")
		phone := r.FormValue("phone")
		insForm, err := db.Prepare("INSERT INTO Member(name, surname, address, phone) VALUES(?,?,?,?)")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(name, surname, address, phone)
		log.Println("INSERT: Name: " + name + " | Surname: " + surname + " | Address: " + address + " | Phone: " + phone)

	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Update is the representation of the update tmpl
func Update(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		name := r.FormValue("name")
		surname := r.FormValue("surname")
		address := r.FormValue("address")
		phone := r.FormValue("phone")
		id := r.FormValue("uid")
		insForm, err := db.Prepare("UPDATE Member SET Name=?, Surname=?, Address=?, Phone=? WHERE Id=?")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(name, surname, address, phone, id)
		log.Println("UPDATE: Name: " + name + " | Surname: " + surname + " | Address: " + address + " | Phone: " + phone)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Delete is the representation of the delete tmpl
func Delete(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	emp := r.URL.Query().Get("id")
	delForm, err := db.Prepare("DELETE FROM Member WHERE id=?")
	if err != nil {
		panic(err.Error())
	}
	delForm.Exec(emp)
	log.Println("DELETE")
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}
