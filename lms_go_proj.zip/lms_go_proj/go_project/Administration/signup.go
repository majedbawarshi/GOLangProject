package main

import (
	"database/sql"
	"fmt"
	"net/http"

	"../../go_projects/books"
	"../../go_projects/members"
	"../../go_projects/reservation"
	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)

var isLoggedIn bool = false

func main() {
	db, err = sql.Open("mysql", "root:turkey_12345@tcp(127.0.0.1:3306)/lms")
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		panic(err.Error())
	}

	http.HandleFunc("/signup", signupPage)
	http.HandleFunc("/", loginPage)
	http.HandleFunc("/main", mainpage)
	http.HandleFunc("/members/", members.Index)
	http.HandleFunc("/members/show", members.Show)
	http.HandleFunc("/members/new", members.New)
	http.HandleFunc("/members/edit", members.Edit)
	http.HandleFunc("/members/insert", members.Insert)
	http.HandleFunc("/members/update", members.Update)
	http.HandleFunc("/members/delete", members.Delete)
	http.HandleFunc("/reservation/", reservation.Index)
	http.HandleFunc("/reservation/show", reservation.Show)
	http.HandleFunc("/reservation/new", reservation.New)
	http.HandleFunc("/reservation/edit", reservation.Edit)
	http.HandleFunc("/reservation/insert", reservation.Insert)
	http.HandleFunc("/reservation/update", reservation.Update)
	http.HandleFunc("/reservation/delete", reservation.Delete)
	http.HandleFunc("/books/", books.Index)
	http.HandleFunc("/books/show", books.Show)
	http.HandleFunc("/books/new", books.New)
	http.HandleFunc("/books/edit", books.Edit)
	http.HandleFunc("/books/insert", books.Insert)
	http.HandleFunc("/books/update", books.Update)
	http.HandleFunc("/books/delete", books.Delete)
	http.ListenAndServe(":8080", nil)

}

var db *sql.DB
var err error

func signupPage(res http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		http.ServeFile(res, req, "signup.html")
		return
	}

	username := req.FormValue("username")
	password := req.FormValue("password")

	var user string

	err := db.QueryRow("SELECT username FROM admin WHERE username=?", username).Scan(&user)

	switch {
	case err == sql.ErrNoRows:
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
		if err != nil {
			http.Error(res, "Server error, unable to create your account.", 500)
			return
		}

		_, err = db.Exec("INSERT INTO admin(username, password) VALUES(?, ?)", username, hashedPassword)
		if err != nil {
			http.Error(res, "Server error, unable to create your account.", 500)
			return
		}
		http.Redirect(res, req, "/main", 301)
		return

	case err != nil:
		http.Error(res, "Server error, unable to create your account.", 500)
		return
	default:
		http.Redirect(res, req, "/", 301)
	}
}

func loginPage(res http.ResponseWriter, req *http.Request) {
	fmt.Print(isLoggedIn)
	if !isLoggedIn {
		if req.Method != "POST" {
			http.ServeFile(res, req, "index.html")
			return
		}

		username := req.FormValue("username")
		password := req.FormValue("password")

		var databaseUsername string
		var databasePassword string

		err := db.QueryRow("SELECT username, password FROM admin WHERE username=?", username).Scan(&databaseUsername, &databasePassword)

		if err != nil {
			http.Redirect(res, req, "/index", 301)
			return
		}
		http.Redirect(res, req, "/main", 301)

		err = bcrypt.CompareHashAndPassword([]byte(databasePassword), []byte(password))
		if err != nil {
			http.Redirect(res, req, "/index", 301)

			return
		}
		http.Redirect(res, req, "/main", 301)

	}
	isLoggedIn = true
}

func homePage(res http.ResponseWriter, req *http.Request) {
	http.ServeFile(res, req, "index.html")
}

func mainpage(res http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		http.ServeFile(res, req, "main.html")
		return
	}
}
