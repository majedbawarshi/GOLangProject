package books

import (
	"database/sql"
	"log"
	"net/http"
	"text/template"

	_ "github.com/go-sql-driver/mysql"
)

//Books is the representation of the Books table
type Books struct {
	Id        int
	Author    string
	Title     string
	Available bool
}

func dbConn() (db *sql.DB) {

	db, err := sql.Open("mysql", "root:turkey_12345@tcp/lms")
	if err != nil {
		panic(err.Error())
	}
	return db
}

var tmpl = template.Must(template.ParseGlob("book/*"))

//Index is the representation of the index tmpl
func Index(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	selDB, err := db.Query("SELECT * FROM Books ORDER BY id ASC")
	if err != nil {
		panic(err.Error())
	}
	emp := Books{}
	res := []Books{}
	for selDB.Next() {
		var id int
		var author, title string
		var available bool
		err = selDB.Scan(&id, &author, &title, &available)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Author = author
		emp.Title = title
		emp.Available = available
		res = append(res, emp)
	}
	tmpl.ExecuteTemplate(w, "Index", res)
	defer db.Close()
}

//Show is the representation of the show tmpl
func Show(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM Books WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Books{}
	for selDB.Next() {
		var id int
		var author, title string
		var available bool
		err = selDB.Scan(&id, &author, &title, &available)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Author = author
		emp.Title = title
		emp.Available = available
	}
	tmpl.ExecuteTemplate(w, "Show", emp)
	defer db.Close()
}

//New is the representation of the new tmpl
func New(w http.ResponseWriter, r *http.Request) {
	tmpl.ExecuteTemplate(w, "New", nil)
}

//Edit is the representation of the edit tmpl
func Edit(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM Books WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Books{}
	for selDB.Next() {
		var id int
		var author, title string
		var available bool
		err = selDB.Scan(&id, &author, &title, &available)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.Author = author
		emp.Title = title
		emp.Available = available
	}
	tmpl.ExecuteTemplate(w, "Edit", emp)
	defer db.Close()
}

//Insert is the representation of the insert tmpl
func Insert(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		author := r.FormValue("author")
		title := r.FormValue("title")
		available := r.FormValue("available")
		insForm, err := db.Prepare("INSERT INTO Books(author, title, available) VALUES(?,?,?)")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(author, title, available)
		log.Println("INSERT: Author: " + author + " | Title: " + title + " | Available: " + available)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Update is the representation of the update tmpl
func Update(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		author := r.FormValue("author")
		title := r.FormValue("title")
		available := r.FormValue("available")
		id := r.FormValue("uid")
		insForm, err := db.Prepare("UPDATE Books SET author=?, title=?, available=? WHERE id=?")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(author, title, available, id)
		log.Println("UPDATE: Author: " + author + " | Title: " + title + " | Available: " + available)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Delete is the representation of the delete tmpl
func Delete(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	emp := r.URL.Query().Get("id")
	delForm, err := db.Prepare("DELETE FROM Books WHERE id=?")
	if err != nil {
		panic(err.Error())
	}
	delForm.Exec(emp)
	log.Println("DELETE")
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}
