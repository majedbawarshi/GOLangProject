package reservation

import (
	"database/sql"
	"log"
	"net/http"
	"text/template"

	_ "github.com/go-sql-driver/mysql"
)

//Isborrowed is the representation of the borrowing table
type Isborrowed struct {
	Id         int
	MemberID   int
	BookID     int
	IssueDate  string
	ReturnDate string
}

func dbConn() (db *sql.DB) {

	db, err := sql.Open("mysql", "root:turkey_12345@tcp/lms")
	if err != nil {
		panic(err.Error())
	}
	return db
}

var tmpl = template.Must(template.ParseGlob("res/*"))

//Index is the representation of the index tmpl
func Index(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	selDB, err := db.Query("SELECT * FROM isborrowed ORDER BY id ASC")
	if err != nil {
		panic(err.Error())
	}
	emp := Isborrowed{}
	res := []Isborrowed{}
	for selDB.Next() {
		var id, memberID, bookID int
		var issueDate, returnDate string
		err = selDB.Scan(&id, &memberID, &bookID, &issueDate, &returnDate)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.MemberID = memberID
		emp.BookID = bookID
		emp.IssueDate = issueDate
		emp.ReturnDate = returnDate
		res = append(res, emp)
	}
	tmpl.ExecuteTemplate(w, "Index", res)
	defer db.Close()
}

//Show is the representation of the show tmpl
func Show(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM isborrowed  WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Isborrowed{}
	for selDB.Next() {
		var id, memberID, bookID int
		var issueDate, returnDate string
		err = selDB.Scan(&id, &memberID, &bookID, &issueDate, &returnDate)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.MemberID = memberID
		emp.BookID = bookID
		emp.IssueDate = issueDate
		emp.ReturnDate = returnDate
	}
	tmpl.ExecuteTemplate(w, "Show", emp)
	defer db.Close()
}

//New is the representation of the new tmpl
func New(w http.ResponseWriter, r *http.Request) {
	tmpl.ExecuteTemplate(w, "New", nil)
}

//Edit is the representation of the edit tmpl
func Edit(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	nId := r.URL.Query().Get("id")
	selDB, err := db.Query("SELECT * FROM isborrowed WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	emp := Isborrowed{}
	for selDB.Next() {
		var id, memberID, bookID int
		var issueDate, returnDate string
		err = selDB.Scan(&id, &memberID, &bookID, &issueDate, &returnDate)
		if err != nil {
			panic(err.Error())
		}
		emp.Id = id
		emp.MemberID = memberID
		emp.BookID = bookID
		emp.IssueDate = issueDate
		emp.ReturnDate = returnDate
	}
	tmpl.ExecuteTemplate(w, "Edit", emp)
	defer db.Close()
}

//Insert is the representation of the insert tmpl
func Insert(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		memberID := r.FormValue("memberID")
		bookID := r.FormValue("bookID")
		issueDate := r.FormValue("issueDate")
		returnDate := r.FormValue("returnDate")
		insForm, err := db.Prepare("INSERT INTO isborrowed(memberID, bookID, issueDate, returnDate) VALUES(?,?,?,?)")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(memberID, bookID, issueDate, returnDate)
		log.Println("INSERT: memberID: " + memberID + " | bookID: " + bookID + " | issueDate: " + issueDate + " | returnDate: " + returnDate)

	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Update is the representation of the update tmpl
func Update(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	if r.Method == "POST" {
		memberID := r.FormValue("memberID")
		bookID := r.FormValue("bookID")
		issueDate := r.FormValue("issueDate")
		returnDate := r.FormValue("returnDate")
		id := r.FormValue("uid")
		insForm, err := db.Prepare("UPDATE isborrowed SET memberID=?, bookID=?, issueDate=?, returnDate=? WHERE Id=?")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(memberID, bookID, issueDate, returnDate, id)
		log.Println("UPDATE: memberID: " + memberID + " | bookID: " + bookID + " | issueDate: " + issueDate + " | returnDate: " + returnDate)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}

//Delete is the representation of the delete tmpl
func Delete(w http.ResponseWriter, r *http.Request) {
	db := dbConn()
	emp := r.URL.Query().Get("id")
	delForm, err := db.Prepare("DELETE FROM isborrowed WHERE id=?")
	if err != nil {
		panic(err.Error())
	}
	delForm.Exec(emp)
	log.Println("DELETE")
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}
